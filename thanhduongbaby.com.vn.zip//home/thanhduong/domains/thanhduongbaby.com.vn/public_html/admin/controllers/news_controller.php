<?php
class NewsController extends AppController {

	var $name = 'News';
	var $helpers = array('Html', 'Form', 'Javascript', 'TvFck');
	var $components = array('function');
		var $uses=array('News','Category');

	function index($id=null) {
	
	
		  $this->account();
		  $menu=$this->Category->read(null,$id);
		 //pr($menu['Category']['level']);die;
		  if( $menu['Category']['level']==0)
		  {
  		 		$_SESSION['menu1']=$id;
		 	}
		   
		 else
		  {
			  // pr($menu['Category']['level']);
		$z=$this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.level'=>0,'Category.lft <'=>$menu['Category']['lft'],'Category.rght >'=>$menu['Category']['rght']),'order'=>'Category.id DESC','fields'=>array('Category.id')));
  
  		 $_SESSION['menu1']=$z[0]['Category']['id'];
		 }

		 $_SESSION['menu2']=$id;
		  //$_SESSION['aa']=$id;
		 //pr($_SESSION['menu2']);die;
	  
		 // $conditions=array('News.status'=>1);
		 	 $dm=$this->Category->read(null, $id);
			 $this->set('tendm',$dm);
			// $dmct=$this->Category->read(null, $dm['']);
			 
		 
		  $x=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.id'=>$id),'order'=>'Category.id DESC','fields'=>array('Category.lft')));//lay vi tri ben trai cua danh muc		 
		 $y=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.id'=>$id),'order'=>'Category.id DESC','fields'=>array('Category.rght')));//lay vị tri ben phai cua danh muc
		if($x[$id]==($y[$id]-1)){			 
		$this->paginate = array('conditions'=>array('News.Category_id'=>$id),'order'=>'News.id DESC','limit'=>6);
	    $this->set('news', $this->paginate('News',array()));	
		$this->set('cat', $this->Category->read(null, $id));
		 }//goi list sp cua danh muc khi no la con be nhat va ten cua danh muc do
		  if($x[$id]<($y[$id]-1)){
		$z=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.lft >'=>$x[$id],'Category.rght <'=>$y[$id]),'order'=>'Category.id DESC','fields'=>array('Category.id')));
		//if($)
		 //$x=$this->set('cat',$this->Category->read(null,318));
		// pr($z);die;
		
		$this->paginate = array('conditions'=>array('News.Category_id'=>$z),'order'=>'News.id DESC','limit'=>12);
	    $this->set('news', $this->paginate('News',array()));	
				$this->set('cat', $this->Category->read(null, $id));
				
				
				

		  }
		
			   
        $a=$this->Category->find('all',array('conditions'=>array('Category.id'=>$id),'fields' => array('Category.lft','Category.rght')));
  // pr($a[0]['Category']['lft']);die;
   
  $x=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.lft >'=>$a[0]['Category']['lft'],'Category.rght <'=>$a[0]['Category']['rght']),'order'=>'Category.id DESC','fields'=>array('Category.id')));//lay vi tri cac danh muc
        $list_cat = $this->Category->generatetreelist(array('Category.id' =>$x),null,null," _ ");
        $this->set(compact('list_cat'));
	  // pr($list_cat);die;
	   $this->set(compact('list_cat'));
	   
		$this->set('cat', $this->Category->read(null, $id));
		$cat1=$this->Category->find('list',array('conditions'=>array('Category.id'=>$id),'order'=>'Category.id DESC','fields'=>array('Category.name')));
		$this->set(compact('cat1'));
		 
	}
	
	//Them moi
	function add($id=null) {
		$this->account();
			 $dm=$this->Category->read(null, $id);
			 $this->set('tendm',$dm);
			 $x=count($this->News->find('all',array('conditions'=>array('News.category_id'=>$id))));
		$this->set('countdm',$x);
		if (!empty($this->data)) {
			$this->News->create();
			$data['News'] = $this->data['News'];
			$data['Category'] = $this->data['Category'];
			//	pr($data['Category']['parent_id']);die;
			$data['News']['category_id']=$data['Category']['parent_id'];
		//pr( $this->function->image_thumb($data['News']['image']));die;
			if(isset($data['News']['image'])==true){
			$data['News']['image_thumb'] = $this->function->image_thumb($data['News']['image']);}
			if($data['News']['alias'] == '')
				$data['News']['alias'] = $this->function->khongdau($data['News']['title']);
			if ($this->News->save($data['News'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index/'.$id));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
		  $a=$this->Category->find('all',array('conditions'=>array('Category.id'=>$id),'fields' => array('Category.lft','Category.rght')));
  // pr($a[0]['Category']['lft']);die;
   
  $x=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.lft >'=>$a[0]['Category']['lft'],'Category.rght <'=>$a[0]['Category']['rght']),'order'=>'Category.id DESC','fields'=>array('Category.id')));//lay vi tri cac danh muc
        $list_cat = $this->Category->generatetreelist(array('Category.id' =>$x),null,null," _ ");
        $this->set(compact('list_cat'));
	  // pr($list_cat);die;
	   $this->set(compact('list_cat'));
	 
		$this->set('cat', $this->Category->read(null, $id));
			$cat1=$this->Category->find('list',array('conditions'=>array('Category.id'=>$id),'order'=>'Category.id DESC','fields'=>array('Category.name')));
		$this->set(compact('cat1'));
	}
	// sua tin da dang
	function edit($id = null) {
	 $a= $this->News->read(null, $id);		
		$this->account();
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại ', true));
			$this->redirect(array('action' => 'index/'.$a['Category']['id']));
		}
		if (!empty($this->data)) {
			$data['News'] = $this->data['News'];
if(isset($data['News']['image'])==true){
			$data['News']['image_thumb'] = $this->function->image_thumb($data['News']['image']);}			//pr($this->data);die;
			if($data['News']['alias'] == '')
				$data['News']['alias'] = $this->function->khongdau($data['News']['title']);
			if ($this->News->save($data['News'])) {
				$this->Session->setFlash(__('Bài viết sửa thành công', true));
				$this->redirect(array('action' => 'index/'.$a['Category']['id']));
			} else {
				$this->Session->setFlash(__('Bài viết này không sửa được vui lòng thử lại.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->News->read(null, $id);
		}	
	  
	   	   //pr($a['Category']['id']);die;
   $this->set('cat2', $this->News->read(null, $id));
  $x=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.lft <'=>$a['Category']['lft'],'Category.rght >'=>$a['Category']['rght'],'Category.level'=>0),'order'=>'Category.id DESC','fields'=>array('Category.id')));//lay vi tri cac danh muc
        $list_cat = $this->Category->generatetreelist(array('Category.id' =>$x),null,null," _ ");
        $this->set(compact('list_cat'));
	  // pr($list_cat);die;
	   $this->set(compact('list_cat'));
	 
		$this->set('cat3', $this->Category->find('list',array('conditions'=>array('Category.id'=>$a['Category']['id']),'order'=>'Category.id DESC','fields'=>array('Category.name'))));
			$cat1=$this->Category->find('list',array('conditions'=>array('Category.id'=>$id),'order'=>'Category.id DESC','fields'=>array('Category.name')));
		$this->set(compact('cat1'));
	}
	//view mot tin 
	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Không tồn tại', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('views', $this->News->read(null, $id));
	}
	//close tin tuc
	function close($id=null) {
		$this->account();
		$a= $this->News->read(null, $id);
		$ad=$a['Category']['id'];
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại bài viết này', true));
			$this->redirect(array('action'=>'index/'.$ad));
		}
		$data['News'] = $this->data['News'];
		$data['News']['status']=0;
		if ($this->News->save($data['News'])) {
			$this->Session->setFlash(__('Bài viết không được hiển thị', true));
			$this->redirect(array('action'=>'index/'.$ad));
		}
		$this->Session->setFlash(__('Bài viết không close được', true));
		$this->redirect(array('action' =>'index/'.$ad));

	}
	
	// active tin bai viêt
	function active($id=null) {
		$this->account();
		$a= $this->News->read(null, $id);
		$ad=$a['Category']['id'];
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại bài viết này', true));
			$this->redirect(array('action'=>'index/'.$ad));
		}
		$data['News'] = $this->data['News'];
		$data['News']['status']=1;
		if ($this->News->save($data['News'])) {
			$this->Session->setFlash(__('Bài viết được hiển thị', true));
			$this->redirect(array('action'=>'index/'.$ad));
		}
		$this->Session->setFlash(__('Bài viết không hiển được bài viết', true));
		$this->redirect(array('action' =>'index/'.$ad));
	}
	// tim kiem san pham
	/*function search() {
		$data['News']=$this->data['News'];
		$category=$data['News']['Category_id'];
		$this->paginate = array('conditions'=>array('News.Category_id'=>$category),'limit' => '15','order' => 'News.id DESC');
	    $this->set('News', $this->paginate('News',array()));
		 $this->loadModel("Category");
        $list_cat = $this->Category->generatetreelist(null,null,null," _ ");
        $this->set(compact('list_cat'));
		
	}*/
	function search() {
		$this->loadModel("Category");
	   $keyword="";
	   $list_cat="";
	  
	   if(isset($_POST['keyword']))
		$keyword=$_POST['keyword'];
		
		if(isset($_POST['list_cat']))
		$list_cat=$_POST['list_cat'];
		$x=array();
		if($keyword!="")
		$x['News.title like']='%'.$keyword.'%';
		
		if($list_cat!="")
		$x['News.Category_id']=$list_cat;
		//pr($x);exit;
		$tt =array();
		$portfolio=$this->Category->find('all',array('conditions'=>array('Category.parent_id'=>$x)));		
		//pr($portfolio);
		foreach($portfolio as $key){
		$tt[]=$key['Category']['id'];
		}
		for($i=0;$i<count($tt);$i++)
		 if($list_cat==$tt[$i])
		 $list_cat=$this->Category->find('list',array('conditions'=>array('Category.parent_id'=>$tt[$i]),'fields'=>array('Category.id')));	
		 if($list_cat!="")
		$x['News.Category_id']=$list_cat;
		//pr($x); die;
		//
	    //$this->set('News', $this->paginate('News',array()));	
		//pr($x);
		$this->paginate = array('conditions'=>$x,'limit' => '12','order' => 'News.id DESC');
		$this->set('News', $this->paginate('News',array()));	
		//$ketquatimkiem=$this->News->find('all',array('conditions'=>$x,'order' => 'News.id DESC','limit'=>3));	
		//pr($ketquatimkiem); die;
		//$this->set('News',$category);
		 $this->loadModel("Category");
        $list_cat = $this->Category->generatetreelist(null,null,null," _ ");
        $this->set(compact('list_cat'));
		
	}
	
	function processing() {
		$this->account();
		if(isset($_POST['dropdown']))
			$select=$_POST['dropdown'];
			
		if(isset($_POST['checkall']))
				{
			
			switch ($select){
				case 'active':
				$News=($this->News->find('all'));
				foreach($News as $News) {
					$News['News']['status']=1;
					$this->News->save($News['News']);					
				}
				//vong lap active
				break;
				case 'notactive':	
				//vong lap huy
				$News=($this->News->find('all'));
				foreach($News as $News) {
					$new['News']['status']=0;
					$this->News->save($News['News']);					
				}
				break;
				case 'delete':
				$News=($this->News->find('all'));
				foreach($News as $News) {
					$this->News->delete($News['News']['id']);					
				}
				if($this->News->find('count')<1)
					$this->redirect(array('action' => 'index'));	
				 else
				 {
					$this->Session->setFlash(__('Danh mục không close được', true));
					$this->redirect(array('action' => 'index'));
				 }
				//vong lap xoa
				break;
				
			}
		}
		else{
			
			switch ($select){
				case 'active':
				$News=($this->News->find('all'));
				foreach($News as $News) {
					if(isset($_POST[$News['News']['id']]))
					{
						$News['News']['status']=1;
						$this->News->save($News['News']);
					}
				}
				//vong lap active
				break;
				case 'notactive':	
				//vong lap huy
				$News=($this->News->find('all'));
				foreach($News as $News) {
					if(isset($_POST[$News['News']['id']]))
					{
						$new['News']['status']=0;
						$this->News->save($News['News']);
					}
				}
				break;
				case 'delete':
				$News=($this->News->find('all'));
				foreach($News as $News) {
					if(isset($_POST[$News['News']['id']]))
					{
					    $this->News->delete($News['News']['id']);
						$this->redirect(array('action'=>'index'));
					}
										
				}
				
				die;	
				//vong lap xoa
				break;
				
			}
			
		}
		$this->redirect(array('action' => 'index'));
		
	}
	// Xoa cac dang
	function delete($id = null) {
			$this->account();	
		$a= $this->News->read(null, $id);
		$ad=$a['Category']['id'];
	
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại bài viết này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->News->delete($id)) {
			$this->Session->setFlash(__('Xóa bài viết thành công', true));
			$this->redirect(array('action'=>'index/'.$ad));
		}
		$this->Session->setFlash(__('Bài viết không xóa được', true));
		$this->redirect(array('action' => 'index/'.$ad));
	}
	
	function _find_list() {
		return $this->Category->generatetreelist(null, null, null, '__');
	}
	//check ton tai tai khoan
	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	// chon layout
	function beforeFilter(){
		$this->layout='admin';
	}

}
?>
