<?php
class MenusController extends AppController {

	var $name = 'Menus';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Overall','Category'); 
	function index($id=null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index/1'));
		}
		if (!empty($this->data)) {
			
			$data['Overall'] = $this->data['Overall'];
			//$hinhbaner=explode('/',$_POST['wbaner']);	
			$hinhnen=explode('/',$_POST['pmenu']);	
//pr($hinhnen);die;
			if(isset($_POST['pmenu'])==true){
					$maunen='background:url(../images/'.$hinhnen[3].') repeat-x;';

				}
			else{
				$maunen='background:#'.$_POST['mmenu'].';';
				
				}
				$hinhnen1=explode('/',$_POST['pmenu1']);	

			if(isset($_POST['pmenu1'])==true){
					$maunen1='background:url(../images/'.$hinhnen1[3].') repeat-x;';

				}
			else{
				$maunen1='background:#'.$_POST['mmenu'].';';
				}
			if(isset($_POST['pmenu'])==true)
			{
				$border='border:#'.$_POST['bmenu'].' 1px solid;';
			}
			else{
				$border='';
			}
			$ftong="../../app/webroot/css/stylemenu.css";
			@$fttong=fopen($ftong,"w");//-----------------------
					$catmain=$this->Overall->read(null,1);

					$ccc=explode('</>',$catmain['Overall']['mainsize']);
	$ul='#q_menu{
			width:auto;
			margin-top:'.$_POST['wmenu2'].'px;
		margin-bottom:'.$_POST['wmenu3'].'px;
		float:left;
		}
	
	#q_menu ul{
		float:left; 
		width:'.($_POST['wmenu']-2).'px;
		margin-left:'.$_POST['wmenu1'].'px;
	
'.$border.'
		display:inline;
		text-transform:uppercase;
font-weight:bold;
'.$maunen.'
;
}
#q_menu ul li{float:left;
position:relative;
'.$maunen.'

}
#q_menu ul li a{float:left; 
padding-left:'.$_POST['ghtren'].'px;
padding-right:'.$_POST['ghtren'].'px;
display:inline;
line-height:'.$_POST['caomenu'].'px;
color:#'.$_POST['cmenu'].';

}
#q_menu ul li a:hover{
'.$maunen1.'
color:#'.$_POST['cmenu1'].';

}
#q_menu ul li li,
#q_menu ul li li li,
#q_menu ul li li li li,
#q_menu ul li li li li li{ width:'.$_POST['smenu'].'px; float:left;
position:relative;
z-index:1000;
}
#q_menu ul li ul li a,
#q_menu ul li ul li ul li a,
#q_menu ul li ul li ul li ul li a,
#q_menu ul li ul li ul li ul li ul li a
{width:'.($_POST['smenu']-5).'px;
padding:0px
padding-left:5px;
float:left;
	}
	#q_menu ul li ul li a:hover,
#q_menu ul li ul li ul li a:hover,
#q_menu ul li ul li ul li ul li a:hover,
#q_menu ul li ul li ul li ul li ul li a:hover
{width:'.($_POST['smenu']-5).'px;
padding:0px;
padding-left:5px;
float:left;
'.$maunen1.'
color:#'.$_POST['cmenu1'].';
overflow:hidden;

}
#q_menu ul li ul,
#q_menu ul li ul li ul,
#q_menu ul li ul li ul li ul {display:none; width:'.$_POST['smenu'].'px;}
#q_menu ul li:hover ul.menu1
{ display:block; position:absolute;float:left; margin:0px; margin-top:'.($_POST['caomenu']+1).'px;z-index:1000;}
#q_menu ul li ul li:hover ul.menu2,
#q_menu ul li ul li ul li ul li:hover ul.menu3
{ display:block; position:absolute;float:left; margin:0px; margin-left:'.$_POST['smenu'].'px;z-index:1000;}
';//------------------------------		
	/*		$ul='#q_menu ul{
		float:left; 
		width:'.$_POST['wmenu'].'px;
		margin-left:'.$_POST['wmenu1'].'px;
		'.$border.'
		display:inline;
		text-transform:uppercase;
font-weight:bold;
		'.$maunen.'
	}';
	$li='#q_menu ul li{float:left;}
';
	$a='#q_menu ul li a{float:left; 
padding-left:'.$_POST['ghtren'].'px;
padding-right:'.$_POST['ghtren'].'px;
display:inline;
line-height:34px;
color:#'.$_POST['cmenu'].';

}
';
	$ahover='#q_menu ul li a:hover{
		'.$maunen1.'
color:#'.$_POST['cmenu1'].';

}
';*/

			$ftong=$ul; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong,$ftong);
						

			$data['Overall']['menutype']=$_POST['checktk'];
			$data['Overall']['mensize']=$_POST['whinh'].'/a/'. $_POST['ghtren'].'/a/'.$_POST['wmenu'].'/a/'.$_POST['wmenu1'].'/a/'.$_POST['pmenu'].'/a/'.$_POST['bmenu'].'/a/'.$_POST['cmenu'].'/a/'.$_POST['pmenu1'].'/a/'.$_POST['cmenu1'].'/a/'.$_POST['smenu'].'/a/'.$_POST['wmenu2'].'/a/'.$_POST['wmenu3'].'/a/'.$_POST['caomenu'];
				
//pr($data['Overall']);die;
	$data['Overall']['codemenucss']=$ul;
	if ($this->Overall->save($data['Overall'])) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."menus'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
		
		
		if (empty($this->data)) {
			$this->data = $this->Overall->read(null, $id);
		}	
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chosetypebaner',explode('/',$catmain['Overall']['menutype']));
		$this->set('chosebaner',explode('/a/',$catmain['Overall']['mensize']));
		
		//pr(explode('/a/',$catmain['Overall']['mainsize']));die;
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
	}
	//Them bai viet
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
