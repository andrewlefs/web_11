<?php
class CommentController extends AppController {

	var $name = 'Comment';
	var $uses=array('Category','News','Gallery','Helps','Video','Slideshow','Partner');
		var $helpers = array('Html', 'Form', 'Javascript', 'TvFck');

	//thong tin thi truong
	
	function anhbg($id=null){
		return  $this->Album->find('all',array('conditions'=>array('Album.display2'=>1),'order'=>'Album.id DESC'));		
	}
function danhmuccha($id=null){
		return  $this->Category->find('all',array('conditions'=>array('Category.level'=>0,'Category.display'=>array(1,5,6,7)),'order'=>'Category.id DESC'));		
	}
function danhmuccha2(){
		return  $this->Category->find('all',array('conditions'=>array('Category.level'=>0,'Category.display'=>array(1,2,3,4)),'order'=>'Category.id DESC'));		
	}
	
	function menu2($id=null){
			$x=$this->Category->read(null,$id);

		
		return $this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.lft >='=>$x['Category']['lft'],'Category.rght <='=>$x['Category']['rght']),'order'=>'Category.lft ASC'));
	}
	
		function menu3(){
		
		return $this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.display'=>3),'order'=>'Category.id DESC'));
	}
	function menu4(){
		
		return $this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.level'=>1,'Category.display'=>4),'order'=>'Category.id DESC'));
	}
	function farther($id=null){
		return $this->Category->read(null,$id);	

		
	}

	
}

?>
