<?php
class ContentsController extends AppController {

	var $name = 'Contents';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Overall','Category'); 
	function index($id=null) {
		$catmain1=$this->Overall->read(null,1);
		$widthmenu=explode('</>',$catmain1['Overall']['mainsize']);
		//pr($widthmenu[8]);die;
		//pr(explode('</>',$catmain1['Overall']['mainsize']));die;
		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index/1'));
		}
		if (!empty($this->data)) {
			
			$a=$_POST['home1'].'/'.$_POST['home2'].'/'.$_POST['home3'].'/'.$_POST['home4'].'/'.$_POST['home5'].'/'.$_POST['home6'].'/'.$_POST['home7'].'/'.$_POST['home8'].'/'.$_POST['home9'].'/'.$_POST['home10'].'/'.$_POST['home11'].'/'.$_POST['home12'].'/'.$_POST['home13'].'/'.$_POST['home14'].'/'.$_POST['home15'].'/'.$_POST['home16'].'/'.$_POST['home17'].'/'.$_POST['home18'].'/'.$_POST['home19'].'/'.$_POST['home20'].'/'.$_POST['home21'].'/'.$_POST['home22'].'/'.$_POST['home23'].'/'.$_POST['home24'].'/'.$_POST['home25'];
	$b=$_POST['hienthi'].'/'.$_POST['checksp1'];
		$csslft='
#q_warrper #q_content {
		float:left;
		width:'.$_POST['home1'].'px;
		margin-left:'.$_POST['home2'].'px;
	
	}	
	a.titlea{
		float: right;
		margin-right:'.(($_POST['home9']-$_POST['home24'])/2).'px;
		width:'.$_POST['home4'].'px;
		line-height:'.$_POST['home5'].'px;
		height:'.$_POST['home5'].'px;
		text-align:center;
		border-radius:'.$_POST['home20'].'px;
		background:url(../'.$widthmenu[6].')repeat-x;
		}
 a{
	color:#'.$_POST['home3'].';
	
	}
#q_warrper #q_content a{
	color:#'.$_POST['home3'].';
	
	}
	#q_warrper #q_content #nd_sp {
		float:left;
width:100%;
height:auto;
		}
#q_warrper #q_content #nd_sp ul{
	float:left;
	width:100%;
	}
#q_warrper #q_content #nd_sp ul li{
	float:left;
	home11
	}		
#q_warrper #q_content #nd_sp ul li
	{
		float:left;
		width:'.$_POST['home9'].'px;
		height:'.$_POST['home8'].'px;
		background:#'.$_POST['home11'].';
		border:#'.$_POST['home10'].' 1px solid;
		margin-top:'.$_POST['home23'].'px;
		margin-left:'.$_POST['home23'].'px;
		overflow:hidden;
		text-align:center; 
	}
#q_warrper #q_content #nd_sp ul li img.imgct{
		width:'.$_POST['home24'].'px;
		height:'.$_POST['home21'].'px;
		margin-top:'.(($_POST['home9']-$_POST['home24'])/2).'px;
		margin-left:'.(($_POST['home9']-$_POST['home24'])/2).'px; 
		float:left
		}
#q_warrper #q_content #news{
		float:left;
		width:100%;
		border-bottom:#'.$_POST['home7'].' 1px solid;
		height:'.$_POST['home6'].'px;
	}
	
#q_warrper #q_content #news img{
	float:left;
	margin:5px;
	height:'.($_POST['home6']-10).'px;
	width:'.$_POST['home25'].'px;
}
#q_warrper #q_content #news .newstext{
	float:left;
	height:'.($_POST['home6']-10).'px;
	width:'.($_POST['home1']-$_POST['home25']-15).'px;
	margin-top:5px
}
		';
		
				
		$data['Overall']['chosetong']=$a;
		$data['Overall']['sizetong']=$b;
		$data['Overall']['contentcss']=$csslft;
				
		//$data['Overall']['leftmodul']=$left;	
		//$data['Overall']['leftmodulsize']=$leftstyle;
		//pr($leftstyle);die;
			/*$ftong="../../app/views/elements/left.ctp";

			@$fttong=fopen($ftong,"w");//-----------------------
$ul=' ';
$abc=array();
$abc[$_POST['vt1']]=$ulmenu;
$abc[$_POST['vt2']]=$ulhotro;
$abc[$_POST['vt3']]=$ulsanpham;
$abc[$_POST['vt4']]=$ulnew;
$abc[$_POST['vt5']]=$ulvideo;
$abc[$_POST['vt6']]=$ulqc;
$abc[$_POST['vt7']]=$ulthoitiet;
$abc[$_POST['vt8']]=$uldangnhap;
$abc[$_POST['vt9']]=$ultimkiem;

$ul="";
for($i=0; $i<10;$i++){@$ul=$ul.$abc[$i];}
//pr($ul);die;*/
			//$ftong=$ul; // pr( $ftong);die; //Khai báo nội dung của file
   // fwrite($fttong,$ftong);
		$ftong2="../../app/webroot/css/contentstyle.css";

			@$fttong2=fopen($ftong2,"w");//-----------------------
	$ftong2=$csslft;
	 fwrite($fttong2,$ftong2);
	$data['Overall']['codecontentcss']=$csslft;					
	if ($this->Overall->save($data['Overall'])) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."contents'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
		
		
		if (empty($this->data)) {
			$this->data = $this->Overall->read(null, $id);
		}	
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chosemd=$this->set('chosemd',explode('/',$catmain['Overall']['leftchose']));
	//$chosevt=$this->set('chosevt',explode('/',$catmain['Overall']['leftvt']));
		$this->set('chosebaner',explode('/a/',$catmain['Overall']['mensize']));
		$chosemd13=$this->set('chosemd13',explode('/',$catmain['Overall']['chosetong']));
		$chosemd14=$this->set('chosemd14',explode('/',$catmain['Overall']['sizetong']));
		$chosestyle=$this->set('chosestyle',explode('/a/',$catmain['Overall']['leftmodulsize']));
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
	}
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
