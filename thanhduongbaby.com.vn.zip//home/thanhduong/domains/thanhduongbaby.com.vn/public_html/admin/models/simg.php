<?php
class Simg extends AppModel {
    var $name = 'Simg';

}
?>
