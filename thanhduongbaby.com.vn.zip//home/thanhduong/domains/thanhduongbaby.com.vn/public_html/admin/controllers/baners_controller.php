<?php
class BanersController extends AppController {

	var $name = 'Baners';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Overall','Category'); 
	function index($id=null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index/1'));
		}
		if (!empty($this->data)) {
			
			$data['Overall'] = $this->data['Overall'];
			//$hinhbaner=explode('/',$_POST['wbaner']);
			$hinh=explode('/',$_POST['wbaner'])	;
			$type=explode('.',$hinh[3])	;
			$hinhlogo=explode('/',$_POST['logo']);
			$hinhgh=explode('/',$_POST['whinh']);
			
			if($type[1]=='swf'){
				$ulnen='
<object width="'.$_POST['wbanner'].'px" height="'.$_POST['hbanner'].'px" title="flash" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" viewastext="">
<param name="_cx" value="14552">
<param name="_cy" value="4577">
<param name="FlashVars" value="">
<param name="Movie" value="<?php echo DOMAIN;?>images/'.$hinh[3].'">
<param name="Src" value="<?php echo DOMAIN;?>images/'.$hinh[3].'">
<param name="WMode" value="transparent">
<param name="Play" value="-1">
<param name="Loop" value="-1">
<param name="Quality" value="High">
<param name="SAlign" value="">
<param name="Menu" value="-1">
<param name="Base" value="">
<param name="AllowScriptAccess" value="">
<param name="Scale" value="ShowAll">
<param name="DeviceFont" value="0">
<param name="EmbedMovie" value="0">
<param name="BGColor" value="FFFFFF">
<param name="SWRemote" value="">
<param name="MovieData" value="">
<param name="SeamlessTabbing" value="1">
<param name="Profile" value="0">
<param name="ProfileAddress" value="">
<param name="ProfilePort" value="0">
<param name="AllowNetworking" value="all">
<param name="AllowFullScreen" value="false">
<embed width="'.$_POST['wbanner'].'px" height="'.$_POST['hbanner'].'px" src="<?php echo DOMAIN;?>images/'.$hinh[3].'" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" wmode="transparent">
</object>

				';
			}	
			if($type[1]=='png' or $type[1]=='gif' or $type[1]=='jpeg' or $type[1]=='jpg'){
				$ulnen='
<img src="<?php echo DOMAIN;?>images/'.$hinh[3].'" style="width:'.$_POST['wbanner'].'px; height:'.$_POST['hbanner'].'px;" />

				';
			}
			$ullogo='
<div style="position:absolute; z-index:100;width:'.$_POST['wlogo'].'px; height:'.$_POST['hlogo'].'px; left:'.$_POST['logotrai'].'px; top:'.$_POST['logophai'].'px;">
	<a href="<?php echo DOMAIN;?>"><img src="<?php echo DOMAIN;?>images/'.$hinhlogo[3].'" style=" float:left;width:'.$_POST['wlogo'].'px; height:'.$_POST['hlogo'].'px;" /></a>
</div>
			';
			 if($_POST['checktk']==1){
			$ultimkiem='

<div style="position:absolute; z-index:100;left:'.$_POST['tktrai'].'px; top:'.$_POST['tktren'].'px; ">
	<form action="<?php echo DOMAIN;?>tim-kiem.html" method="post" style="float:left;">
    <input type="text" name="check"  value="Tìm kiếm" style="float:left;" class="text"/>
    <input type="submit" style="float:left;  display:inline;" value="Tìm kiếm" class="bottom" />
    </form>
</div>
			';
			 }
			 if($_POST['checktk']==0){
	 			$ultimkiem=' ';

			 }
			  if($_POST['checkgh']==1){ 
				$ulgiohang='   
<div style="position:absolute; z-index:100;left:'.$_POST['ghtrai'].'px; top:'.$_POST['ghtren'].'px;">
<a href="<?php echo DOMAIN;?>xem-gio-hang.html"><img src="<?php echo DOMAIN;?>images/'.$hinhgh[3].'" /> </a><b>Giỏ hàng</b>
</div>
 ';}
		  if($_POST['checkgh']==0){ 
		  $ulgiohang='';
		  }
			//pr($type[1]);die;
			
			
			$ftong="../../app/webroot/css/stylbaner.css";
			 @$fttong=fopen($ftong,"w");
			 $baner='
#q_baner{
	width:'.$_POST['wbanner'].'px;
	height:'.$_POST['hbanner'].'px;
	float:left;
	position:relative;

		}';
			$ftong=$baner; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong,$ftong);			

			$data['Overall']['banerchose']=$_POST['checktk'].'/'.$_POST['checkgh'];
			$data['Overall']['banercss']=$_POST['wbaner'].'/a/'. $_POST['logo'].'/a/'.$_POST['wlogo'].'/a/'.$_POST['hlogo'].'/a/'.$_POST['logotrai'].'/a/'.$_POST['logophai'].'/a/'.$_POST['tktrai'].'/a/'.$_POST['tktren'].'/a/'.$_POST['ghtrai'].'/a/'.$_POST['ghtren'].'/a/'.$_POST['whinh'].'/a/'.$_POST['wbanner'].'/a/'.$_POST['hbanner'];
				
//pr($data['Overall']);die;
$ftong="../../app/webroot/css/banner.css"; //Khai báo đường dẫn của file cần ghi dữ liệu
			// Khởi tạo css cho toàn bộn trang------------------------------------------------------------------------>
   @$fttong=fopen($ftong,"w"); 
$css='
#q_baner{
	width:990px;
	height:148px;
	float:left;
	position:relative;
}
   ';
   
$ftong=$css; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong,$ftong); //thực hiện ghi css
$ftong1="../../app/views/elements/baner.ctp"; //Khai báo đường dẫn của file cần ghi dữ liệu
			// Khởi tạo css cho toàn bộn trang------------------------------------------------------------------------>
  @$fttong1=fopen($ftong1,"w"); 
  $banerhtml=$ulnen; 
$ftong1=$banerhtml.$ullogo.$ultimkiem.$ulgiohang; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong1,$ftong1); 
$data['Overall']['codebanerhtml']=$banerhtml.$ullogo.$ultimkiem.$ulgiohang;
$data['Overall']['codebanercss']=$css;
	
	if ($this->Overall->save($data['Overall'])) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."baners'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
		
		
		if (empty($this->data)) {
			$this->data = $this->Overall->read(null, $id);
		}	
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chosetypebaner',explode('/',$catmain['Overall']['banerchose']));
		$this->set('chosebaner',explode('/a/',$catmain['Overall']['banercss']));
		//pr(explode('/a/',$catmain['Overall']['mainsize']));die;
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
	}
	//Them bai viet
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
