<?php
class SibaleftsController extends AppController {

	var $name = 'Sibalefts';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Overall','Category'); 
	function index($id=null) {
		$catmain1=$this->Overall->read(null,1);
		$widthmenu=explode('</>',$catmain1['Overall']['mainsize']);
		//pr($widthmenu[7]);die;
		//pr(explode('</>',$catmain1['Overall']['mainsize']));die;
		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index/1'));
		}
		if (!empty($this->data)) {
			
			$data['Overall'] = $this->data['Overall'];
	
		 $cssmenutong='
		 #q_left{
	width:'.$_POST['mn1'].'px;
	height:auto;
	padding-left:'.$_POST['mn9'].'px;
	float:left;
			 }
		 #q_left #sp_left{
	float:left;
	width:'.($_POST['mn1']).'px;
	padding-bottom:'.$_POST['mn6'].'px;
	margin-bottom:'.$_POST['mn8'].'px;
	height:auto;
	display:inline;
	background:#'.$_POST['mn7'].';
	border:1px #'.$_POST['mn5'].' solid;
	border-radius:'.$_POST['mn6'].'px;
	
	
	}	
	
		 ';//kết thuc mã css cho sibaleft
  if($_POST['check1']==0){		$cssmenu='';
								
								
										$ulmenu='';	}
	
						if($_POST['check1']==1){				
								$a1=1;
								$b1=$_POST['vt1'];
								$left1=$_POST['menumaunen']."/".$_POST['menumauchu']."/".$_POST['menuct']."/".$_POST['menutext']."/".$_POST['checkmn1']."/".$_POST['menumaunen1']."/".$_POST['menumauchu1'];								if($_POST['checkmn1']==0){
									//bắt dầu cho menu sổ
									$ulmenu='
<script type="text/javascript" src="<?php echo DOMAIN;?>js/webwidget_vertical_menu.js"></script>
 <link href="<?php echo DOMAIN;?>css/webwidget_vertical_menu.css" rel="stylesheet" type="text/css"></link>

       <script language="javascript" type="text/javascript">
            $(function() {
                $("#webwidget_vertical_menu").webwidget_vertical_menu({
                    menu_width: "'.($_POST['mn1']-2).'",
                    menu_height: "'.$_POST['menuct'].'",
                    menu_margin: "0",
                    menu_text_size: "'.$_POST['menutext'].'",
                    menu_text_color: "#'.$_POST['menumauchu1'].'",
                    menu_background_color: "#'.$_POST['menumaunen1'].'",
                    menu_border_size: "1",
                    menu_border_color: "#'.$_POST['mn5'].'",
                    menu_border_style: "solid",
                    menu_background_hover_color: "#'.$_POST['menumaunen'].'",
                    directory: "images"
                });
            });
        </script><div id="sp_left">
                	 <?php $menu2 = $this->requestAction("/comment/menu2"); ?>
<?php foreach($menu2 as $menu2){?> 

                	  
                        	<div id="q_title"><p><?php echo $menu2["Category"]["nametrai"];?></p> </div>
                              <?php $link = $this->requestAction("/comment/link/".$menu2["Category"]["id"]);  ?>
       					 <div id="webwidget_vertical_menu" class="webwidget_vertical_menu"  style="float:left;">  
                            <?php foreach($link as $link){$b=explode("/",$link["Category"]["alias1"]);?>
                            <?php echo $this->Help->getMultiMenu2($menu2["Category"]["id"],$b[0],false); ?>
                            <?php }?>
            			  			<div style="clear: both"></div>
       					 </div>
                   
									<?php }?> </div>';//kết thúc mã html cho menu
									//kết thúc mã css cho menu
									$cssmenu=' ';
									}
								if($_POST['checkmn1']==1){
										$ulmenu='

        <div id="sp_left">
                	 <?php $menu2 = $this->requestAction("/comment/menu2"); ?>
<?php foreach($menu2 as $menu2){?> 

                	  
                        	<div id="q_title"><p><?php echo $menu2["Category"]["nametrai"];?></p>  </div>
                              <?php $link = $this->requestAction("/comment/link/".$menu2["Category"]["id"]);  ?>
                            <?php foreach($link as $link){$b=explode("/",$link["Category"]["alias1"]);?>
                            <?php echo $this->Help->getMultiMenu3($menu2["Category"]["id"],$b[0],false); ?>
                            <?php }?>
						 <?php }?> </div>
						 ';//kết thúc mã html cho menu
									//kết thúc mã css cho menu
								$cssmenu='
								#q_left #sp_left a.menu{
		width:'.($_POST['mn1']-9).'px;
		padding-left:5px;
		color:#'.$_POST['menumauchu1'].';
		background:#'.$_POST['menumaunen1'].';
		float:left;
		font-size:'.$_POST['menutext'].'px;
		font-weight:bold;
		line-height:'.$_POST['menuct'].'px;
		text-transform:uppercase;
	} 
	#q_left #sp_left a.menu:hover{
		width:'.($_POST['mn1']-9).'px;
		padding-left:5px;
		color:#'.$_POST['menumauchu'].';
		background:#'.$_POST['menumaunen'].';
		float:left;
		font-size:'.$_POST['menutext'].'px;
		font-weight:bold;
		line-height:'.$_POST['menuct'].'px;
		text-transform:uppercase;
	} 
								';
									}
							
							}
							else
							{
								$a1=0;
								$b1=0;
								$left1="Null";
								$ulmenu=" ";
								}//end---------------------------menu-----------------------------------------------------------
						if($_POST['check2']==1){				
								$a2=1;
								$b2=$_POST['vt2'];
								$left2=$_POST['hotrocao'];
								$ulhotro='<div id="sp_left">
                    	
                        		<div id="q_title"><p>'.$left2.'</p></div>
                        	<?php $hotline = $this->requestAction("/comment/hotline");?> 
                                          <?php foreach($hotline as $hotline) {?> 
                                       <div style="width:91%;height:auto; margin-left:10px; line-height:24px; border-bottom:1px #333 dotted;  float:left;">
Điện thoại:
<b style=" margin-left:5px; display:inline;"><?php echo $hotline["Helps"]["sdt1"];?></b>
<br>
<b style="float:left"><?php echo $hotline["Helps"]["name"];?>:</b>
<a style="float:left;" href="ymsgr:sendim?<?php echo $hotline["Helps"]["yahoo1"];?>">
<img width="65" height="17" border="0" style="float:left; margin-left:10px;" src="http://opi.yahoo.com/online?u=<?php echo $hotline["Helps"]["yahoo1"];?>&m=g&t=1&l=us">
</a>
</div><?php }?>
                            
                        
                         </div>';
							
							}
							else
							{
								$a2=0;
								$b2=0;
								$left2="Null";
								$ulhotro=' ';
								}
						if($_POST['check3']==1){				
								$a3=1;
								$b3=$_POST['vt3'];
								$left3=$_POST['sanphamcao']."/".$_POST['checksp1']."/".$_POST['sanphamcao1']."/".$_POST['sanphamcao2']."/".$_POST['sanphamcao3']."/".$_POST['sanphamcao4'];
								$csssanpham='
#conten_main_right-jcarousellite_spleft{
	width:'.($_POST['mn1']).'px !important;
	height:'.($_POST['sanphamcao3']*$_POST['sanphamcao2']).'px !important;
	line-height:24px;	
}							
#conten_main_right-jcarousellite_spleft img.img{
	width:'.($_POST['sanphamcao1']).'px;
	height:'.($_POST['sanphamcao4']).'px;
	margin-left:'.((($_POST['mn1'])-$_POST['sanphamcao1'])/2).'px;
}	
#conten_main_right-jcarousellite_spleft #text{
	margin-left:'.((($_POST['mn1'])-$_POST['sanphamcao1'])/2).'px;
	width:'.($_POST['mn1']).'px !important;
}

								';//ket thúc csss cho sản phẩm chay
								if($_POST['checksp1']==2){
								$ulsanpham=' 
								<div id="sp_left">
								<script src=" <?php echo DOMAIN;?>js/jcarousellite_1.0.1c4.js"  type="text/javascript"></script>

    <script type="text/javascript">
$(function() {
 $("#conten_main_right-jcarousellite_spleft").jCarouselLite({
  vertical: true,
  hoverPause:true,
  visible:'.$_POST['sanphamcao2'].',
  auto:500,
  speed:2000
 });
});</script>        <div id="q_title"><p>'.$_POST['sanphamcao'].'</p></div>
    <div id="conten_main_right-jcarousellite_spleft" style=" float:left;">
    <?php $sellerproduct = $this->requestAction("/comment/sellerproduct") ?>
    <ul style="float:left;">
    <?php foreach($sellerproduct as $sellerproducts ){  ?>
    <li style="float:left">
            <a href="<?php echo DOMAIN;?>chi-tiet-san-pham/<?php echo $sellerproducts["Product"]["id"]?>/<?php echo $sellerproducts["Product"]["alias"]?>.html" >
       <img  src="<?php echo $sellerproducts["Product"]["image_thumb"]?>" class="img" />  </a>
	        <div id="text">

            <a href="<?php echo DOMAIN;?>chi-tiet-san-pham/<?php echo $sellerproducts["Product"]["id"]?>/<?php echo $sellerproducts["Product"]["alias"]?>.html" class="link">
				<?php echo $sellerproducts["Product"]["title"] ?>
            </a><br />
            Gia:<?php echo $sellerproducts["Product"]["price"] ?> VND
       
        <a href="<?php echo DOMAIN?>products/addshopingcart/<?php echo $sellerproducts["Product"]["id"]?>" class="titlea">
        Chọn mua
        </a>
   <div>
    </li>
    <?php } ?>
    </ul>
    </div>
</div>
								
								';}// kết thuc dang 1 cua san phâm chay=============================================
								if($_POST['checksp1']==1){
								$ulsanpham=' 
								<div id="sp_left">
								<script src=" <?php echo DOMAIN;?>js/jcarousellite_1.0.1c4.js"  type="text/javascript"></script>

    <script type="text/javascript">
$(function() {
 $("#conten_main_right-jcarousellite_spleft").jCarouselLite({
  vertical: true,
  hoverPause:true,
  visible:'.$_POST['sanphamcao2'].',
  auto:500,
  speed:2000
 });
});</script>         <div id="q_title"> <p>'.$_POST['sanphamcao'].'</p></div>
    <div id="conten_main_right-jcarousellite_spleft" style=" float:left;">
    <?php $sellerproduct = $this->requestAction("/comment/sellerproduct") ?>
    <ul style="float:left;">
    <?php foreach($sellerproduct as $sellerproducts ){  ?>
    <li style="float:left">
          
	        <div id="text">

            <a href="<?php echo DOMAIN;?>chi-tiet-san-pham/<?php echo $sellerproducts["Product"]["id"]?>/<?php echo $sellerproducts["Product"]["alias"]?>.html" class="link">
				<?php echo $sellerproducts["Product"]["title"] ?>
            </a><br />
            Gia:<?php echo $sellerproducts["Product"]["price"] ?> VND
       
        <a href="<?php echo DOMAIN?>products/addshopingcart/<?php echo $sellerproducts["Product"]["id"]?>" class="titlea">
        Chọn mua
        </a>
   <div>
    </li>
    <?php } ?>
    </ul>
    </div>
</div>
								
								';}// kết thuc dang 1 cua san phâm chay=============================================
								if($_POST['checksp1']==0){
								$ulsanpham=' 
								<div id="sp_left">
								<script src=" <?php echo DOMAIN;?>js/jcarousellite_1.0.1c4.js"  type="text/javascript"></script>

    <script type="text/javascript">
$(function() {
 $("#conten_main_right-jcarousellite_spleft").jCarouselLite({
  vertical: true,
  hoverPause:true,
  visible:'.$_POST['sanphamcao2'].',
  auto:500,
  speed:2000
 });
});</script>         <div id="q_title"> <p>'.$_POST['sanphamcao'].'</p></div>
    <div id="conten_main_right-jcarousellite_spleft" style=" float:left;">
    <?php $sellerproduct = $this->requestAction("/comment/sellerproduct") ?>
    <ul style="float:left;">
    <?php foreach($sellerproduct as $sellerproducts ){  ?>
    <li style="float:left">
            <a href="<?php echo DOMAIN;?>chi-tiet-san-pham/<?php echo $sellerproducts["Product"]["id"]?>/<?php echo $sellerproducts["Product"]["alias"]?>.html" >
       <img  src="<?php echo $sellerproducts["Product"]["image_thumb"]?>" class="img" />  </a>
	       
    </li>
    <?php } ?>
    </ul>
    </div>
</div>
								
								';}// kết thuc dang 1 cua san phâm chay=============================================
							}
							else
							{
								$a3=0;
								$b3=0;
								$left3="Null";
								$ulsanpham=' ';
								$csssanpham=' ';
								}// kết thuc dang 1 cua san phâm chay=============================================
						if($_POST['check4']==1){				
								$a4=1;
								$b4=$_POST['vt4'];
								$left4=$_POST['tincao']."/".$_POST['checktin1']."/".$_POST['tincao1']."/".$_POST['tincao2']."/".$_POST['tincao3']."/".$_POST['tincao4'];			
						$cssnew='
#conten_main_right-jcarousellite_splefttin{
	width:'.($_POST['mn1']).'px !important;
	height:'.($_POST['tincao3']*$_POST['tincao2']).'px !important;
	line-height:24px;	
}							
#conten_main_right-jcarousellite_splefttin img.img{
	height:'.($_POST['tincao4']).'px;
	width:'.($_POST['tincao1']).'px;
	margin-left:'.((($_POST['mn1'])-$_POST['tincao1'])/2).'px;
}	
#conten_main_right-jcarousellite_splefttin #text{
	margin-left:'.((($_POST['mn1'])-$_POST['tincao1'])/2).'px;
	width:'.($_POST['mn1']).'px !important;
}

								';//ket thúc csss cho sản phẩm chay
								if($_POST['checktin1']==2){
								$ulnew=' 
								<div id="sp_left">
								<script src=" <?php echo DOMAIN;?>js/jcarousellite_1.0.1c4.js"  type="text/javascript"></script>

    <script type="text/javascript">
$(function() {
 $("#conten_main_right-jcarousellite_splefttin").jCarouselLite({
  vertical: true,
  hoverPause:true,
  visible:'.$_POST['tincao2'].',
  auto:500,
  speed:2000
 });
});</script>        <div id="q_title"><p>'.$_POST['tincao'].'</p></div>
    <div id="conten_main_right-jcarousellite_splefttin" style=" float:left;">
    <?php $tinhot = $this->requestAction("/comment/tinhot") ?>
    <ul style="float:left;">
    <?php foreach($tinhot as $tinhots ){  ?>
    <li style="float:left">
            <a href="<?php echo DOMAIN;?>chi-tiet-tin/<?php echo $tinhots["News"]["id"]?>/<?php echo $tinhots["News"]["alias"]?>.html" >
       <img  src="<?php echo $tinhots["News"]["image_thumb"]?>" class="img" />  </a>
	        <div id="text">

            <a href="<?php echo DOMAIN;?>chi-tiet-tin/<?php echo $tinhots["News"]["id"]?>/<?php echo $tinhots["News"]["alias"]?>.html" class="link">
				<?php echo $tinhots["News"]["title"] ?>
            </a><br /> <div>
    </li>
    <?php } ?>
    </ul>
    </div>
</div>
								
								';}// kết thuc dang 1 cua san phâm chay=============================================
								if($_POST['checktin1']==1){
								$ulnew=' 
								<div id="sp_left">
								<script src=" <?php echo DOMAIN;?>js/jcarousellite_1.0.1c4.js"  type="text/javascript"></script>

    <script type="text/javascript">
$(function() {
 $("#conten_main_right-jcarousellite_splefttin").jCarouselLite({
  vertical: true,
  hoverPause:true,
  visible:'.$_POST['tincao2'].',
  auto:500,
  speed:2000
 });
});</script>         <div id="q_title"> <p>'.$_POST['tincao'].'</p></div>
    <div id="conten_main_right-jcarousellite_splefttin" style=" float:left;">
    <?php $tinhot = $this->requestAction("/comment/tinhot") ?>
    <ul style="float:left;">
    <?php foreach($tinhot as $tinhots ){  ?>
    <li style="float:left">
          
	        <div id="text">

            <a href="<?php echo DOMAIN;?>chi-tiet-tin/<?php echo $tinhots["News"]["id"]?>/<?php echo $tinhots["News"]["alias"]?>.html" class="link">
				<?php echo $tinhots["News"]["title"] ?>
            </a><br /> <div>
    </li>
    <?php } ?>
    </ul>
    </div>
</div>
								
								';}// kết thuc dang 1 cua san phâm chay=============================================
								if($_POST['checktin1']==0){
								$ulnew=' 
								<div id="sp_left">
								<script src=" <?php echo DOMAIN;?>js/jcarousellite_1.0.1c4.js"  type="text/javascript"></script>

    <script type="text/javascript">
$(function() {
 $("#conten_main_right-jcarousellite_splefttin").jCarouselLite({
  vertical: true,
  hoverPause:true,
  visible:'.$_POST['tincao2'].',
  auto:500,
  speed:2000
 });
});</script>          <div id="q_title"><p>'.$_POST['tincao'].'</p></div>
    <div id="conten_main_right-jcarousellite_splefttin" style=" float:left;">
    <?php $tinhot = $this->requestAction("/comment/tinhot") ?>
    <ul style="float:left;">
    <?php foreach($tinhot as $tinhots ){  ?>
    <li style="float:left">
            <a href="<?php echo DOMAIN;?>chi-tiet-tin/<?php echo $tinhots["News"]["id"]?>/<?php echo $tinhots["News"]["alias"]?>.html" >
       <img  src="<?php echo $tinhots["News"]["image_thumb"]?>" class="img" />  </a>
	       
    </li>
    <?php } ?>
    </ul>
    </div>
</div>
								
								';}		
								
								
						

							}
							else
							{
								$a4=0;
								$b4=0;
								$left4="Null";
								$ulnew=' ';
								$cssnew=' ';
								}	
						if($_POST['check5']==1){				
								$a5=1;
								$b5=$_POST['vt5'];
								$left5=$_POST['videocao'];
								$ulvideo='
								<div id="sp_left">
							<div id="q_title"><p>'.$_POST['videocao'].'</p></div>
							    <?php $videos = $this->requestAction("/comment/videos") ?>

								<center>
								<iframe width="'.($_POST['mn1']-10).'" height="'.(($_POST['mn1']-10)*0.75).'" src="http://www.youtube.com/embed/<?php echo $videos["Video"]["videouot"]?>" frameborder="0" allowfullscreen style=" margin-top:10px; margin-bottom:10px;"></iframe>
								</center>
							</div>
								
								 ';

								
							}
							else
							{
								$a5=0;
								$b5=0;
								$left5="Null";
								$ulvideo=' ';

								}			
						if($_POST['check6']==1){				
								$a6=1;
								$b6=$_POST['vt6'];
								$left6=$_POST['quangcao'].'/'.$_POST['quangcao1'].'/'.$_POST['quangcao2'].'/'.$_POST['quangcao3'].'/'.$_POST['quangcao4'];
								$ulqc=' 
			<div id="sp_left">
			<div id="q_title"><p>'.$_POST['quangcao'].'</p></div>
    <?php $quangcao = $this->requestAction("/comment/quangcao/'.$_POST['quangcao3'].'") ?>
    <?php foreach($quangcao as $quangcao ){  ?>
          
       <img  src="<?php echo $quangcao["Gallery"]["images"]?>" class="quangcao" /> 
	       
    <?php } ?>
</div>
';
								$cssqc='
#sp_left img.quangcao {
	width:'.$_POST['quangcao1'].'px !important;
	height:'.$_POST['quangcao2'].'px !important;
	margin-left:'.((($_POST['mn1']-2)-$_POST['quangcao1'])/2).'px;
	display:inline;
	float:left;
	margin-top:'.$_POST['quangcao4'].'px;

}							
								
								 ';
							}
							else
							{
								$a6=0;
								$b6=0;
								$left6="Null";
								$ulqc=' ';
								$cssqc=' ';
								}		
						if($_POST['check7']==1){				
								$a7=1;
								$b7=$_POST['vt7'];
								$left7=$_POST['thoitietcao'].'/'.$_POST['thoitietcao1'].'/'.$_POST['thoitietcao2'];
								$ulthoitiet=' 
					<div id="sp_left">
							<div id="q_title"><p>'.$_POST['thoitietcao'].'</p></div>
								<center>
									
								<iframe frameborder="0" marginwidth="0" marginheight="0" src="http://www.nhomvietvic.com.vn/weather1/?size='.$_POST['thoitietcao2'].'&fsize=12&bg=images/bg.png&repeat=repeat-x&r=1&w=1&g=1&col=1&d=0" width="'.$_POST['thoitietcao1'].'" height="'.$_POST['thoitietcao2'].'" scrolling="no"></iframe>
								
								</center>
								
							
							</div>
								
								';
								
							}
							else
							{
								$a7=0;
								$b7=0;
								$left7="Null";
								$ulthoitiet=' ';

								}
						if($_POST['check8']==1){				
								$a8=1;
								$b8=$_POST['vt8'];
								$left8=$_POST['dangnhapcao'];
								$uldangnhap='
								<div id="sp_left">
								<div id="q_title"><p>'.$_POST['dangnhapcao'].'</p></div>
            <?php if($this->Session->read("name")){?>
                    <div class="title_r" style="float:left; width:100%;"><p>Khách hàng</p></div>
                   <div class="logout" style=" padding-top:14px; float:left;">
                     <div>Xin chào :<span style="font-weight:bold;"><?php echo $this->Session->read("name")?></span> / <a href="<?php echo DOMAIN;?>login/logout">Thoát</a></div>
                   </div>
                   <?php } else {?>
				
				<div id="div-content" style="float:left">
					<div id="div-boxLogin">
                      <form method="post" action="<?php echo DOMAIN;?>login/check_login">
						<table>
							<tr>
								<td class="left">Tài khoản</td>
								<td class="right"><input type="text" name="email"  value="" style="width:104px;"></td>
							</tr>
							<tr>
								<td class="left">Mật khẩu</td>
								<td class="right"><input type="password" name="password"  value="" style="width:104px;"></td>
							</tr>
							<tr>
								<td class="left"></td>
								<td class="right"><input type="checkbox" name="chkRemember"/>&nbsp;Lưu mật khẩu</td>
							</tr>
							<tr>
								<td class="left"></td>
								<td class="right" align="right"><input type="submit" class="btn" name="btnlogin" value="Đăng nhập"/></td>
							</tr>
							<tr>
								<td class="left"></td>
								<td class="right" align="right"><a href="<?php echo DOMAIN?>user/forgot_password">Quên mật khẩu ?</a></td>
							</tr>
						</table>
                        </form>
					</div>
				</div>
				<div id="div-title">Đăng nhập &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo DOMAIN;?>dang-ky">Đăng ký mới</a></div>
                <?php }?>
			</div>
								 ';
							}
							else
							{
								$a8=0;
								$b8=0;
								$left8="Null";
								$uldangnhap=' ';
								}
						if($_POST['check9']==1){				
								$a9=1;
								$b9=$_POST['vt9'];
								$left9=$_POST['timkiemcao'];
								$ultimkiem='
								<div id="sp_left">
								<div id="q_title"><p>'.$_POST['timkiemcao'].'</p></div>
								<div style="margin:auto; float:left; margin-top:5px;margin-left:15px;">
            <form action="<?php echo DOMAIN;?>tim-kiem.html" method="post">
            
            <input name="name" value="Nhập tên sản phẩm" />
            <input type="submit" value="Tìm kiếm" />
            </form>
			</div>	</div>
								';
							}
							else
							{
								$a9=0;
								$b9=0;
								$left9="Null";
								$ultimkiem=' ';
								}
			$a=$a1."/".$a2."/".$a3."/".$a4."/".$a5."/".$a6."/".$a7."/".$a8."/".$a9;
			$f=$b1."/".$b2."/".$b3."/".$b4."/".$b5."/".$b6."/".$b7."/".$b8."/".$b9;
			$left=$left1."<|>".$left2."<|>".$left3."<|>".$left4."<|>".$left5."<|>".$left6."<|>".$left7."<|>".$left8."<|>".$left9;
			$leftstyle=$_POST['mn1']."/a/".$_POST['mn2']."/a/".$_POST['mn3']."/a/".$_POST['mn4']."/a/".$_POST['mn5']."/a/".$_POST['mn6']."/a/".$_POST['mn7']."/a/".$_POST['mn8']."/a/".$_POST['mn9']."/a/".$_POST['mn10'];
			$c=$a1+$a2+$a3+$a4+$a5+$a6+$a7+$a8+$a9;
			$b=$b1+$b2+$b3+$b4+$b5+$b6+$b7+$b8+$b9;
			$d=0;
			for($i=0;$i<$c+1;$i++){$d=$d+$i;}
			
				
				
		$data['Overall']['leftchose']=$a;
		$data['Overall']['leftvt']=$f;		
		$data['Overall']['leftmodul']=$left;	
		$data['Overall']['leftmodulsize']=$leftstyle;
		//pr($leftstyle);die;
			$ftong="../../app/views/elements/left.ctp";

			@$fttong=fopen($ftong,"w");//-----------------------
$ul=' ';
$abc=array();
$abc[$_POST['vt1']]=$ulmenu;
$abc[$_POST['vt2']]=$ulhotro;
$abc[$_POST['vt3']]=$ulsanpham;
$abc[$_POST['vt4']]=$ulnew;
$abc[$_POST['vt5']]=$ulvideo;
$abc[$_POST['vt6']]=$ulqc;
$abc[$_POST['vt7']]=$ulthoitiet;
$abc[$_POST['vt8']]=$uldangnhap;
$abc[$_POST['vt9']]=$ultimkiem;

$ul="";
for($i=0; $i<10;$i++){@$ul=$ul.$abc[$i];}
//pr($ul);die;
			$ftong=$ul; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong,$ftong);
		$ftong2="../../app/webroot/css/left.css";

			@$fttong2=fopen($ftong2,"w");//-----------------------
			$csslft=$cssmenutong.$cssmenu.$csssanpham.$cssnew.$cssqc;	
	$ftong2=$csslft;
	 fwrite($fttong2,$ftong2);
	$data['Overall']['codelefthtml']=$ul;
	$data['Overall']['codeleftcss']=$csslft;
	
		if ($this->Overall->save($data['Overall'])) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."sibalefts'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
		
		
		if (empty($this->data)) {
			$this->data = $this->Overall->read(null, $id);
		}	
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chosemd=$this->set('chosemd',explode('/',$catmain['Overall']['leftchose']));
		$chosevt=$this->set('chosevt',explode('/',$catmain['Overall']['leftvt']));
		$this->set('chosebaner',explode('/a/',$catmain['Overall']['mensize']));
		$chosemd1=$this->set('chosemd1',explode('<|>',$catmain['Overall']['leftmodul']));
		$chosestyle=$this->set('chosestyle',explode('/a/',$catmain['Overall']['leftmodulsize']));
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
	}
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
