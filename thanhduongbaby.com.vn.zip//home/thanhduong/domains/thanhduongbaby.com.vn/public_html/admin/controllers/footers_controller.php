<?php
class FootersController extends AppController {

	var $name = 'Footers';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Overall','Category'); 
	function index($id=null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index/1'));
		}
		if (!empty($this->data)) {
			
			$data['Overall'] = $this->data['Overall'];
			//$hinhbaner=explode('/',$_POST['wbaner']);
			//$hinh=explode('/',$_POST['wbaner'])	;
			//$type=explode('.',$hinh[3])	;
			//$hinhlogo=explode('/',$_POST['logo']);
			//$hinhgh=explode('/',$_POST['whinh']);
			
			

			$data['Overall']['ftchose']=$_POST['wlogo'].'/'.$_POST['hlogo'].'/'.$_POST['hlogo1'];
			$data['Overall']['ftcss']=2;
			$data['Overall']['fthtml']=2;
//pr($data['Overall']);die;


$ulslide='
	<div style=" width:100%; height:160px; background:#333; float:left;color:#'.$_POST['hlogo1'].'">
					  <?php $ft = $this->requestAction("/comment/ft");?>   
                      <?php echo $ft["Setting"]["mobile"];?>

</div> 

';





$ftong1="../../app/views/elements/footers.ctp"; //Khai báo đường dẫn của file cần ghi dữ liệu
			// Khởi tạo css cho toàn bộn trang------------------------------------------------------------------------>
  @$fttong1=fopen($ftong1,"w"); 
$ftong1=$ulslide; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong1,$ftong1); 
$data['Overall']['codefooterhtml']=$ulslide;
	
	if ($this->Overall->save($data['Overall'])) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."footers'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
		
		
		if (empty($this->data)) {
			$this->data = $this->Overall->read(null, $id);
		}	
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chosetypebaner',explode('/',$catmain['Overall']['banerchose']));
		$this->set('chosebaner',explode('/',$catmain['Overall']['ftchose']));
		//pr(explode('/a/',$catmain['Overall']['mainsize']));die;
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
	}
	//Them bai viet
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
