<?php
class Comment2sController extends AppController {

	var $name = 'Comment2';
	var $helpers = array('Html', 'Form', 'Javascript','TvFck');
	//list danh sach cac danh muc
	function index() {	
	   
	  // $conditions=array('Category.status'=>1);	
	   $this->paginate = array('limit' => '15','order' => 'Comment2.id DESC');
	   $this->set('comment2s', $this->paginate('Comment2',array()));
	}
	//them danh muc moi
	
	function close($id=null) {
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại bài viết này', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Comment2'] = $this->data['Comment2'];
		$data['Comment2']['status']=0;
		if ($this->Comment2->save($data['Comment2'])) {
			$this->Session->setFlash(__('Bài viết không được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Bài viết không close được', true));
		$this->redirect(array('action' => 'index'));

	}
	
	function active($id=null) {
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại bài viết này', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Comment2'] = $this->data['Comment2'];
		$data['Comment2']['status']=1;
		if ($this->Comment2->save($data['Comment2'])) {
			$this->Session->setFlash(__('Bài viết được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Bài viết không hiển được bài viết', true));
		$this->redirect(array('action' => 'index'));
	}
	function edit($id = null) {
		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại ', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$data['Comment2'] = $this->data['Comment2'];
			
			if ($this->Comment2->save($data['Comment2'])) {
				$this->Session->setFlash(__('Bài viết sửa thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Bài viết này không sửa được vui lòng thử lại.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Comment2->read(null, $id);
		}
		$this->loadModel("Category");
        $list_cat = $this->Category->generatetreelist(null,null,null," _ ");
        $this->set(compact('list_cat'));
		$this->set('edit',$this->Comment2->findById($id));
	}
	
	function delete($id = null) {	
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại bài viết này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Comment2->delete($id)) {
			$this->Session->setFlash(__('Xóa bài viết thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Bài viết không xóa được', true));
		$this->redirect(array('action' => 'index'));
	}
	function beforeFilter(){
		$this->layout='admin';
	}
	
	

}
?>
