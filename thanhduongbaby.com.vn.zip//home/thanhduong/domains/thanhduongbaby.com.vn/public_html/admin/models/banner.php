<?php
class Banner extends AppModel {
    var $name = 'Banner';

}
?>
