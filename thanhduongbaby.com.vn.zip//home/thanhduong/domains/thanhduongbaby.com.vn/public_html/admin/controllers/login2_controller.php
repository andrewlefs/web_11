<?php
class Login2Controller extends AppController {

	var $name = 'Login2';
	var $uses=array('User');
	function index() {

	}
	// chekh dang nhap
	
	// chon layout
	function beforeFilter(){
		$this->layout='login';	
	}

}
?>
