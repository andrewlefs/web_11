<?php
class Advertisement extends AppModel {
    var $name = 'Advertisement';
}
?>
