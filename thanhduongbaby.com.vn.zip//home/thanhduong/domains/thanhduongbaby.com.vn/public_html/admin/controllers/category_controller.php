<?php
class CategoryController extends AppController {

	var $name = 'Category';	
	var $helpers = array('Html', 'Form', 'Javascript', 'TvFck');
	//list danh sach cac danh muc
	function index() {	
	   $this->account();	 
	  // $conditions=array('Category.status'=>1);	
	   $this->paginate = array('conditions'=>array('Category.level'=>0),'limit' => '30','order' => 'Category.id DESC');
	   $this->set('Category', $this->paginate('Category',array()));
      
	   $_SESSION['menu1']=4;
   
	}
	function close($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Category'] = $this->data['Category'];
		$data['Category']['id']=$id;
		$data['Category']['status']=0;		
		if ($this->Category->save($data['Category'])) {
			$this->Session->setFlash(__('Danh mục không được hiển thị', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Danh mục không close được', true));
		$this->redirect(array('action' => 'index'));

	}
	// kich hoat
	function active($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'index'));
		}
		$data['Category'] = $this->data['Category'];
		$data['Category']['id']=$id;
		$data['Category']['status']=1;
		if ($this->Category->save($data['Category'])) {
			$this->Session->setFlash(__('Danh mục kích hoạt thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Danh mục không kich hoạt được', true));
		$this->redirect(array('action' => 'index'));

	}

	//Xoa danh muc
	function delete($id = null) {	
		$this->account();	
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Category->delete($id)) {
			$this->Session->setFlash(__('Xóa danh mục thành công', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Danh mục không xóa được', true));
		$this->redirect(array('action' => 'index'));
	}
	//list danh sach cac danh muc
	
	
	
	
	function add() {
		$x=count($this->Category->find('all'));
		$y=count($this->Category->find('all',array('conditions'=>array('Category.level'=>0))));
		$this->set('countdm',$y);
			if($x==0){
				$d=1;
				}
				if($x!=0){
				
			$z=$this->Category->find('all',array('order' => 'Category.code DESC','limit'=>1));
			$d=$z[0]['Category']['code'];
				}
		$this->account();
		if (!empty($this->data)) 
		{
			$data['Category'] = $this->data['Category'];
//$data['Category']['alias']=$_POST['ten'];
			//pr($data['Category']['alias']);die;
			if($data['Category']['order']==0)
			{	echo "<script>alert('Thêm mới menu thất bại. Vui lòng nhập số thứ tự cho menu');</script>";	
echo "<script>location.href='".DOMAINAD."category/add'</script>";}

			if($data['Category']['display']=="")
			{	echo "<script>alert('Thêm mới menu thất bại. Vui lòng chọn chức năng cho menu');</script>";	
echo "<script>location.href='".DOMAINAD."category/add'</script>";
}
else{

			if($data['Category']['display']==1)
			{
				$data['Category']['alias1']='gioi-thieu/'.($d+1).'/'.$_POST['ten'].'.html';
				$data['Category']['name1']='Giới thiệu';
			}
			if($data['Category']['display']==2)
			{  //pr('tin-tuc/'.($x+1).'/'.$_POST['ten'].'.html');die;
				$data['Category']['alias1']='tin-tuc/'.($d+1).'/'.$_POST['ten'].'.html';
				$data['Category']['name1']='Tin tức';
			}
			if($data['Category']['display']==3)
			{
				$data['Category']['alias1']='san-pham/'.($d+1).'/'.$_POST['ten'].'.html';
				$data['Category']['name1']='Sản phẩm';
			}
			if($data['Category']['display']==4)
			{
				$data['Category']['alias1']='dinh-duong/'.($d+1).'/'.$_POST['ten'].'.html';
				$data['Category']['name1']='Dinh dưỡng';
			}
			if($data['Category']['display']==5)
			{
				$data['Category']['alias1']='bang-gia/'.($d+1).'/'.$_POST['ten'].'.html';
				$data['Category']['name1']='Bảng giá';
			}
			if($data['Category']['display']==6)
			{
				$data['Category']['alias1']='lien-he.html';
				$data['Category']['name1']='Liên hệ';
			}
			
			if($data['Category']['display']==7)
			{
				$data['Category']['alias1']='NULL';
				$data['Category']['name1']='Đăng ký đăng nhập';

			}//-----------------
			$data['Category']['alias']=$_POST['ten'];
			$data['Category']['code']=$d+1;
			$this->Category->create();
			
			if ($this->Category->save($data['Category'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}}
		}
		$this->loadModel("Category");
   	}/// kết thuc danh muc me nu---------------------------------------------------------------------------------
	function edit($id = null) {
		$this->account();
		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {$data['Category'] = $this->data['Category'];
		
			$this->Category->create();
			
			if ($this->Category->save($data['Category'])) {
				$this->Session->setFlash(__('Sửa thành công', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Sủa không thành công. Vui long thử lại', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Category->read(null, $id);
			$this->parent_id = $this->Category->read(null, $id);
		}
		//pr($this->data);die;
		$this->set('list_cat',$this->_find_list());
		$this->set('edit', $this->Category->read(null, $id));
	}// Sửa danh muc tại menu-----------------------------------------------------------
	
//=======================================================================================================================================================	
	
		function index1() {	
	   $this->account();	 
	   $this->paginate = array('conditions'=>array('Category.level'=>1),'limit' => '30','order' => 'Category.id DESC');
	   $this->set('Category', $this->paginate('Category',array()));
	   $_SESSION['menu1']=3;
	}
	//tim kiem
	function close1($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'index1'));
		}
		$data['Category'] = $this->data['Category'];
		$data['Category']['id']=$id;
		$data['Category']['status']=0;		
		if ($this->Category->save($data['Category'])) {
			$this->Session->setFlash(__('Danh mục không được hiển thị', true));
			$this->redirect(array('action'=>'index1'));
		}
		$this->Session->setFlash(__('Danh mục không close được', true));
		$this->redirect(array('action' => 'index1'));

	}
	// kich hoat
	function active1($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'index1'));
		}
		$data['Category'] = $this->data['Category'];
		$data['Category']['id']=$id;
		$data['Category']['status']=1;
		if ($this->Category->save($data['Category'])) {
			$this->Session->setFlash(__('Danh mục kích hoạt thành công', true));
			$this->redirect(array('action'=>'index1'));
		}
		$this->Session->setFlash(__('Danh mục không kich hoạt được', true));
		$this->redirect(array('action' => 'index1'));

	}

	//Xoa danh muc
	function delete1($id = null) {	
		$this->account();	
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Category->delete($id)) {
			$this->Session->setFlash(__('Xóa danh mục thành công', true));
			$this->redirect(array('action'=>'index1'));
		}
		$this->Session->setFlash(__('Danh mục không xóa được', true));
		$this->redirect(array('action' => 'index1'));
	}
	function serachtow() {
	$x=array();
	if($_POST['name']!='Tên danh mục'){
		$_SESSION['dm']=$_POST['name'];
		$x['Category.name']=$_SESSION['dm'];
	}
	
	if($_POST['danhmuccha']!=0){
	
		$_SESSION['danhmuccha']=$_POST['danhmuccha'];
		$x['Category.parent_id']=$_SESSION['danhmuccha'];
		}	
		//pr($x);die;
		//$Category=$data['Category']['parent_id'];
		$this->paginate = array('conditions'=>array('Category.level'=>1,$x),'limit' => '15','order' => 'Category.id DESC');
	    $this->set('Category', $this->paginate('Category',array()));
		
        $list_cat = $this->Category->generatetreelist(null,null,null,"--- ");
	    $this->set(compact('list_cat'));
		
	}
	function closeserachtow($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'serachtow'));
		}
		$data['Category'] = $this->data['Category'];
		$data['Category']['id']=$id;
		$data['Category']['status']=0;		
		if ($this->Category->save($data['Category'])) {
			$this->Session->setFlash(__('Danh mục không được hiển thị', true));
			$this->redirect(array('action'=>'serachtow'));
		}
		$this->Session->setFlash(__('Danh mục không close được', true));
		$this->redirect(array('action' => 'serachtow'));

	}
	// kich hoat
	function activeserachtow($id=null) {
		$this->account();
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'serachtow'));
		}
		$data['Category'] = $this->data['Category'];
		$data['Category']['id']=$id;
		$data['Category']['status']=1;
		if ($this->Category->save($data['Category'])) {
			$this->Session->setFlash(__('Danh mục kích hoạt thành công', true));
			$this->redirect(array('action'=>'serachtow'));
		}
		$this->Session->setFlash(__('Danh mục không kich hoạt được', true));
		$this->redirect(array('action' => 'serachtow'));

	}

	//Xoa danh muc
	function deleteserachtow($id = null) {	
		$this->account();	
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Category->delete($id)) {
			$this->Session->setFlash(__('Xóa danh mục thành công', true));
			$this->redirect(array('action'=>'serachtow'));
		}
		$this->Session->setFlash(__('Danh mục không xóa được', true));
		$this->redirect(array('action' => 'serachtow'));
	}
	
		function add1() {
		$x=count($this->Category->find('all'));
		$y=count($this->Category->find('all',array('conditions'=>array('Category.level'=>1))));
		$this->set('countdm',$y);
		$this->account();
		if (!empty($this->data)) 
		{
			$data['Category'] = $this->data['Category'];
			$linh = $this->Category->read(null, $data['Category']['parent_id']);
			$linh2=explode('/',$linh['Category']['alias1']);
			//pr($linh2[0]);die;
			$data['Category']['alias1']=$linh2[0].'/'.($x+1).'/'.$_POST['ten'].'.html';
			$data['Category']['display']=$linh['Category']['display'];
			$data['Category']['code']=$x+1;
			$data['Category']['level']=1;
			$data['Category']['alias']=$_POST['ten'];
			if($data['Category']['parent_id']=="")
			{	echo "<script>alert('Thêm mới dạnh mục thất bại. Vui lòng chọn danh mục cha');</script>";	
echo "<script>location.href='".DOMAINAD."category/add1'</script>";
}
else{
			$this->Category->create();
			
			if ($this->Category->save($data['Category'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'index1'));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui lòng thử lại', true));
			}}
		}
		$this->loadModel("Category");
        $Categorylist = $this->Category->find('list',array('conditions'=>array('Category.level'=>0,'Category.display not'=>array(5,6,7)),'fields'=>array('Category.name')));
        $this->set(compact('Categorylist'));
	}// kết thúc thêm mới danh muc cấp 2--------------------------------
	function edit1($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index1'));
		}
	if (!empty($this->data)) {$data['Category'] = $this->data['Category'];

				$x=count($this->Category->find('all'));
			$linh = $this->Category->read(null, $data['Category']['parent_id']);
			$linh2=explode('/',$linh['Category']['alias1']);
			//pr($linh2[0]);die;
			$data['Category']['alias1']=$linh2[0].'/'.$x.'/'.$_POST['ten'].'.html';
			$data['Category']['display']=$linh['Category']['display'];
			$data['Category']['alias']=$_POST['ten'];
			$data['Category']['level']=1;
			$data['Category']['alias']=$_POST['ten'];
			$this->Category->create();
			
			if ($this->Category->save($data['Category'])) {
				$this->Session->setFlash(__('Sửa thành công', true));
				$this->redirect(array('action' => 'index1'));
			} else {
				$this->Session->setFlash(__('Sủa không thành công. Vui long thử lại', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Category->read(null, $id);
			$this->parent_id = $this->Category->read(null, $id);
		}
		$this->loadModel("Category");
        $Categorylist = $this->Category->find('list',array('conditions'=>array('Category.level'=>0,'Category.display not'=>array(5,6,7)),'fields'=>array('Category.name')));
        $this->set(compact('Categorylist'));
	}// Sửa danh muc caap 2-----------------------------------------------------------
		
	
	//====================================================================================================================
	
		function danhmuc($id=null) {	
	   $this->account();	 
	  
	   $_SESSION['menu2']=$id;
	  
	   $_SESSION['menu1']=2;
	  
       $a=$this->Category->find('all',array('conditions'=>array('Category.id'=>$id)));
 $this->paginate = array('conditions'=>array('Category.lft >'=>$a[0]['Category']['lft'],'Category.rght <'=>$a[0]['Category']['rght']),'limit' => '30','order' => 'Category.id DESC');
	   $this->set('Category', $this->paginate('Category',array()));
 		 $x=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.lft >'=>$a[0]['Category']['lft'],'Category.rght <'=>$a[0]['Category']['rght']),'order'=>'Category.id DESC','fields'=>array('Category.id')));//lay vi tri cac danh muc
        $list_cat = $this->Category->generatetreelist(array('Category.id' =>$x),null,null," _ ");
        $this->set(compact('list_cat'));
		//pr($list_cat);die;
	 
		$this->set('cat', $this->Category->read(null, $id));
			$cat1=$this->Category->find('list',array('conditions'=>array('Category.id'=>$id),'order'=>'Category.id DESC','fields'=>array('Category.name')));
		$this->set(compact('cat1'));
	}
	
	function add2($id=null) {
		$this->account();
					$z=$this->Category->find('all',array('order' => 'Category.code DESC','limit'=>1));

		if (!empty($this->data)) 
		{	
		$x=count($this->Category->find('all'));
		$data['Category'] = $this->data['Category'];

				$x=count($this->Category->find('all'));
			$linh = $this->Category->read(null, $data['Category']['parent_id']);
		
			$linh2=explode('/',$linh['Category']['alias1']);
			//pr($linh2[0]);die;
			$data['Category']['display']=$x+1;
			$data['Category']['alias1']=$linh2[0].'/'.($z[0]['Category']['code']+1).'/'.$_POST['ten'].'.html';
			$data['Category']['display']=$linh['Category']['display'];
			$data['Category']['alias']=$_POST['ten'];
			$data['Category']['level']=$linh['Category']['level']+1;
			$data['Category']['code']=$z[0]['Category']['code']+1;
	//pr($data['Category']);die;
		
		
			$this->Category->create();
			if ($this->Category->save($data['Category'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'danhmuc/'.$id));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
			}
		}
		  $a=$this->Category->find('all',array('conditions'=>array('Category.id'=>$id)));

 		 $x=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.lft >'=>$a[0]['Category']['lft'],'Category.rght <'=>$a[0]['Category']['rght']),'order'=>'Category.id DESC','fields'=>array('Category.id')));//lay vi tri cac danh muc
        $list_cat = $this->Category->generatetreelist(array('Category.id' =>$x),null,null," _ ");
        $this->set(compact('list_cat'));
	 
		$this->set('cat', $this->Category->read(null, $id));
			$cat1=$this->Category->find('list',array('conditions'=>array('Category.id'=>$id),'order'=>'Category.id DESC','fields'=>array('Category.name')));
		$this->set(compact('cat1'));
	 // pr($_SESSION['menu1']);die;
	}
	//Sua danh muc
	
	function edit2($id = null) {
		$this->account();
		
		

		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'danhmuc/'.$id));
		}
		if (!empty($this->data)) {
			$x=count($this->Category->find('all'));
		$data['Category'] = $this->data['Category'];

				$x=count($this->Category->find('all'));
			$linh = $this->Category->read(null, $data['Category']['parent_id']);
		
			$linh2=explode('/',$linh['Category']['alias1']);
			//pr($linh2[0]);die;
			$data['Category']['display']=$x+1;
			//$data['Category']['alias1']=$linh2[0].'/'.($x+1).'/'.$_POST['ten'].'.html';
			$data['Category']['display']=$linh['Category']['display'];
			//$data['Category']['alias']=$_POST['ten'];
			$data['Category']['level']=$linh['Category']['level']+1;
			$data['Category']['code']=$x+1;
//pr($data['Category']['id']);die;
		
		$ax=$this->Category->find('all',array('conditions'=>array('Category.id'=>$data['Category']['id']),'fields' => array('Category.lft','Category.rght')));
		

  $xx=$this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.lft <'=>$ax[0]['Category']['lft'],'Category.rght >'=>$ax[0]['Category']['rght'],'Category.level'=>0),'order'=>'Category.id DESC'));
  
			$this->Category->create();
			if ($this->Category->save($data['Category'])) {
				$this->Session->setFlash(__('Thêm mới danh mục thành công', true));
				$this->redirect(array('action' => 'danhmuc/'.$xx[0]['Category']['id']));
			} else {
				$this->Session->setFlash(__('Thêm mơi danh mục thất bại. Vui long thử lại', true));
		
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Category->read(null, $id);
			$this->parent_id = $this->Category->read(null, $id);
		} 
			
		  $a=$this->Category->find('all',array('conditions'=>array('Category.id'=>$id),'fields' => array('Category.lft','Category.rght')));	

  $x=$this->Category->find('list',array('conditions'=>array('Category.status'=>1,'Category.lft <'=>$a[0]['Category']['lft'],'Category.rght >'=>$a[0]['Category']['rght']),'order'=>'Category.id DESC','fields'=>array('Category.id')));//lay vi tri cac danh muc
        $list_cat = $this->Category->generatetreelist(array('Category.id' =>$x),null,null," _ ");
        $this->set(compact('list_cat'));
	  // pr($x);die;
		$this->set('cat', $this->Category->read(null, $id));
			$cat1=$this->Category->find('list',array('conditions'=>array('Category.id'=>$id),'order'=>'Category.id DESC','fields'=>array('Category.name')));
		$this->set(compact('cat1'));
	}
	function close2($id=null) {
		$this->account();
			$ax=$this->Category->find('all',array('conditions'=>array('Category.id'=>$id),'fields' => array('Category.lft','Category.rght')));
		

  $xx=$this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.lft <'=>$ax[0]['Category']['lft'],'Category.rght >'=>$ax[0]['Category']['rght'],'Category.level'=>1),'order'=>'Category.id DESC'));
		
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'danhmuc/'.$xx[0]['Category']['id']));
		}
		$data['Category'] = $this->data['Category'];
		$data['Category']['id']=$id;
		$data['Category']['status']=0;		
		if ($this->Category->save($data['Category'])) {
			$this->Session->setFlash(__('Danh mục không được hiển thị', true));
			$this->redirect(array('action'=>'danhmuc/'.$xx[0]['Category']['id']));
		}
		$this->Session->setFlash(__('Danh mục không close được', true));
		$this->redirect(array('action' => 'danhmuc/'.$xx[0]['Category']['id']));

	}
	// kich hoat
	function active2($id=null) {
		
		$this->account();
			$ax=$this->Category->find('all',array('conditions'=>array('Category.id'=>$id),'fields' => array('Category.lft','Category.rght')));
		

  $xx=$this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.lft <'=>$ax[0]['Category']['lft'],'Category.rght >'=>$ax[0]['Category']['rght'],'Category.level'=>1),'order'=>'Category.id DESC'));
		
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			$this->redirect(array('action'=>'danhmuc/'.$xx[0]['Category']['id']));
		}
		$data['Category'] = $this->data['Category'];
		$data['Category']['id']=$id;
		$data['Category']['status']=1;
		if ($this->Category->save($data['Category'])) {
			$this->Session->setFlash(__('Danh mục kích hoạt thành công', true));
			$this->redirect(array('action'=>'danhmuc/'.$xx[0]['Category']['id']));
		}
		$this->Session->setFlash(__('Danh mục không kich hoạt được', true));
		$this->redirect(array('action' => 'danhmuc/'.$xx[0]['Category']['id']));

	}

	//Xoa danh muc
	function delete2($id = null) {	
		$this->account();	
			$ax=$this->Category->find('all',array('conditions'=>array('Category.id'=>$id),'fields' => array('Category.lft','Category.rght')));
		

  $xx=$this->Category->find('all',array('conditions'=>array('Category.status'=>1,'Category.lft <'=>$ax[0]['Category']['lft'],'Category.rght >'=>$ax[0]['Category']['rght']),'order'=>'Category.id DESC'));
  //pr($xx);die;
		
		if (empty($id)) {
			$this->Session->setFlash(__('Khôn tồn tại danh mục này', true));
			//$this->redirect(array('action'=>'index'));
		}
		if ($this->Category->delete($id)) {
			$this->Session->setFlash(__('Xóa danh mục thành công', true));
			$this->redirect(array('action'=>'danhmuc/'.$xx[0]['Category']['id']));
		}
		$this->Session->setFlash(__('Danh mục không xóa được', true));
		$this->redirect(array('action' => 'danhmuc/'.$xx[0]['Category']['id']));
	}
	//list danh sach cac danh muc
	
	
	//dong danh muc
	
	function _find_list() {
		return $this->Category->generatetreelist(null, null, null, '--- ');
	}
	//check ton tai tai khoan
	function account(){
		if(!$this->Session->read("id") || !$this->Session->read("name")){
			$this->redirect('/');
		}
	}
	function beforeFilter(){
		$this->layout='admin';
	}

}
?>
