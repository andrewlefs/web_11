<?php
class SildesController extends AppController {

	var $name = 'Sildes';
	
	var $helpers = array('Html','Ajax', 'Form', 'Javascript', 'TvFck');
	var $uses=array('Overall','Category'); 
	function index($id=null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Không tồn tại danh mục này', true));
			$this->redirect(array('action' => 'index/1'));
		}
		if (!empty($this->data)) {
			
			$data['Overall'] = $this->data['Overall'];
			//$hinhbaner=explode('/',$_POST['wbaner']);
			//$hinh=explode('/',$_POST['wbaner'])	;
			//$type=explode('.',$hinh[3])	;
			//$hinhlogo=explode('/',$_POST['logo']);
			//$hinhgh=explode('/',$_POST['whinh']);
			$baner='
			
			#slider_container_2 { float: left; width: '.$_POST['wlogo'].'px; height:'.$_POST['hlogo'].'; }
#slider_container_2 img { float: left; width: '.$_POST['wlogo'].'px; height:'.$_POST['hlogo'].'; }


.SliderName_2 {
	float: left;
	width: '.$_POST['wlogo'].'px;
	height: '.$_POST['hlogo'].';
	overflow: hidden;
}

.SliderNamePrev_2 {
	background: url(../img/left.png) no-repeat left center;
	width: 50px;
	height: '.$_POST['hlogo'].';
	display: block;
	position: absolute;
	top: 0;
	left: 0;
	text-decoration: none;
}

.SliderNameNext_2 {
	background: url(../img/right.png) no-repeat right center;
	width: 50px;
	height: '.$_POST['hlogo'].';
	display: block;
	position: absolute;
	top: 0;
	right: 0;
	text-decoration: none;
}

.SliderName_2Description {
	padding: 10px;
	font-family: Tahoma,Arial,Helvetica;
	font-size: 14px;
	line-height: 30px;
	letter-spacing: 1px;
	text-align: center;
	color: #ffffff;
	text-shadow: 0 1px 3px #000000;
}

#SliderNameNavigation_2 {float:left; margin: 0; padding: 10px 0 0 0; height: 30px; text-align: center; overflow-y: hidden; position:relative; background:url(../img/tit_bg_sl.png) repeat-x; width:'.$_POST['wlogo'].'px; margin-top:-30px; }

#SliderNameNavigation_2 a:link, #SliderNameNavigation_2 a:active, #SliderNameNavigation_2 a:visited, #SliderNameNavigation_2 a:hover{
	margin: 0;
	padding: 0;
	font-size: 0;
	line-height: 0;
	text-decoration: none;
}

#SliderNameNavigation_2 a img
{	float:right;
	border: none;
	width: 16px;
	height: 16px;
	
	background: url(../img/an.png) no-repeat center center;
}

#SliderNameNavigation_2 a.active img
{
	background: url(../img/hien.png) no-repeat center center;
	
}
			
			';
			

			$data['Overall']['slidechose']=$_POST['wlogo'].'/'.$_POST['hlogo'].'/'.$_POST['logotrai'].'/'.$_POST['logophai'].'/'.$_POST['checkgh'];
			$data['Overall']['slidecss']=2;
			$data['Overall']['slidehtml']=2;
//pr($data['Overall']);die;
$ftong="../../app/webroot/css/sliderman.css"; //Khai báo đường dẫn của file cần ghi dữ liệu
			// Khởi tạo css cho toàn bộn trang------------------------------------------------------------------------>
   @$fttong=fopen($ftong,"w"); 

$ftong=$baner; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong,$ftong); //thực hiện ghi css


if($_POST['checkgh']==0){
$ulslide='
	<?php if($this->params["controller"]=="home"){?>
     <div id="slide">
  <div id="wrapper1" style="margin-top:'.$_POST['logophai'].'px; margin-bottom:'.$_POST['logotrai'].'px;float: left;">

		<div id="examples_outer">
		

			<div id="slider_container_2">

				<div id="SliderName_2" class="SliderName_2">
					
					  <?php $slide = $this->requestAction("/comment/slide");?>   
                     <?php foreach($slide as $slide) {?> 
                    <img src="<?php echo $slide["Slideshow"]["images"];?>" />
                    <div class="SliderName_2Description"> <strong><?php echo $slide["Slideshow"]["name"];?></strong></div>
                        <?php }?>
					
				</div>
				<div id="SliderNameNavigation_2"></div>

				<script type="text/javascript">
					effectsDemo2 = "rain,stairs,fade";
					var demoSlider_2 = Sliderman.slider({container: "SliderName_2", width: '.$_POST['wlogo'].', height: '.$_POST['hlogo'].', effects: effectsDemo2,
						display: {
							autoplay: 3000,
							loading: {background: "#000000", opacity: 0.5, image: "img/loading.gif"},
							buttons: {hide: true, opacity: 1, prev: {className: "SliderNamePrev_2", label: ""}, next: {className: "SliderNameNext_2", label: ""}},
							description: {hide: true, background: "#000000", opacity: 0.4, height: 50, position: "bottom"},
							navigation: {container: "SliderNameNavigation_2", label: "<img src=img/clear.gif />"}
						}
					});
				</script>

				<div class="c"></div>
			</div>
			<div class="c"></div>
		</div>

		<div class="c"></div>
	</div>
                    </div>
					<?php }?>
';}
if($_POST['checkgh']==1){
$ulslide='
     <div id="slide">
  <div id="wrapper1" style="margin-top:'.$_POST['logophai'].'px; margin-bottom:'.$_POST['logotrai'].'px;float: left;">

		<div id="examples_outer">
		

			<div id="slider_container_2">

				<div id="SliderName_2" class="SliderName_2">
					
					  <?php $slide = $this->requestAction("/comment/slide");?>   
                     <?php foreach($slide as $slide) {?> 
                    <img src="<?php echo $slide["Slideshow"]["images"];?>" />
                    <div class="SliderName_2Description"> <strong><?php echo $slide["Slideshow"]["name"];?></strong></div>
                        <?php }?>
					
				</div>
				<div id="SliderNameNavigation_2"></div>

				<script type="text/javascript">
					effectsDemo2 = "rain,stairs,fade";
					var demoSlider_2 = Sliderman.slider({container: "SliderName_2", width: '.$_POST['wlogo'].', height: '.$_POST['hlogo'].', effects: effectsDemo2,
						display: {
							autoplay: 3000,
							loading: {background: "#000000", opacity: 0.5, image: "img/loading.gif"},
							buttons: {hide: true, opacity: 1, prev: {className: "SliderNamePrev_2", label: ""}, next: {className: "SliderNameNext_2", label: ""}},
							description: {hide: true, background: "#000000", opacity: 0.4, height: 50, position: "bottom"},
							navigation: {container: "SliderNameNavigation_2", label: "<img src=img/clear.gif />"}
						}
					});
				</script>

				<div class="c"></div>
			</div>
			<div class="c"></div>
		</div>

		<div class="c"></div>
	</div>
                    </div>

';}





$ftong1="../../app/views/elements/slide.ctp"; //Khai báo đường dẫn của file cần ghi dữ liệu
			// Khởi tạo css cho toàn bộn trang------------------------------------------------------------------------>
  @$fttong1=fopen($ftong1,"w"); 
$ftong1=$ulslide; // pr( $ftong);die; //Khai báo nội dung của file
    fwrite($fttong1,$ftong1); 
$data['Overall']['codeslidehtml']=$ulslide;
$data['Overall']['codeslidecss']=$baner;
	
	if ($this->Overall->save($data['Overall'])) {
				echo "<script>alert('Thiết lập cấu hình thành công');</script>";			
			echo "<script>location.href='".DOMAINAD."sildes'</script>";
			} else {
				echo "<script>alert('Thiết lập cấu hình không thành công vui lòng thử lại');</script>";
			}
		}
		
		
		if (empty($this->data)) {
			$this->data = $this->Overall->read(null, $id);
		}	
		$this->set('cat',$this->Overall->read(null,1));
		$catmain=$this->Overall->read(null,1);
		$chose=$this->set('chosetypebaner',explode('/',$catmain['Overall']['banerchose']));
		$this->set('chosebaner',explode('/',$catmain['Overall']['slidechose']));
		//pr(explode('/a/',$catmain['Overall']['mainsize']));die;
		$chose=$this->set('chose',explode('/',$catmain['Overall']['mainchose']));
	}
	//Them bai viet
	function beforeFilter(){
		$this->layout='admin3';
	}
}

?>
