<?php
class Overall extends AppModel {
    var $name = 'Overall';
   
}
?>
